/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package todolistmanagement;

/**
 *
 * @author LENOVO
 */


import java.sql.*;
import java.util.Scanner;

public class TodoListManagement {

    static final String URL =
        "jdbc:mysql://localhost:3306/todolist";
    static final String USER = "root";
    static final String PASSWORD = "DBMS@2026";

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        try (Connection con =
                DriverManager.getConnection(URL, USER, PASSWORD)) {

            while (true) {
                System.out.println("\nTO-DO LIST MANAGEMENT SYSTEM");
                System.out.println("1. Add Task");
                System.out.println("2. View Tasks");
                System.out.println("3. Mark Task Completed");
                System.out.println("4. Delete Task");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");

                int choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {

                    case 1:
                        System.out.print("Enter task name: ");
                        String task = sc.nextLine();

                        String insert =
                            "INSERT INTO tasks (task_name) VALUES (?)";

                        try (PreparedStatement ps =
                                con.prepareStatement(insert)) {
                            ps.setString(1, task);
                            ps.executeUpdate();
                            System.out.println("Task added successfully!");
                        }
                        break;

                    case 2:
                        String select = "SELECT * FROM tasks";

                        try (Statement st = con.createStatement();
                             ResultSet rs = st.executeQuery(select)) {

                            System.out.println("\nYour Tasks:");
                            while (rs.next()) {
                                System.out.println(
                                    rs.getInt("id") + ". " +
                                    rs.getString("task_name") + " - " +
                                    rs.getString("status"));
                            }
                        }
                        break;

                    case 3:
                        System.out.print("Enter task ID: ");
                        int updateId = sc.nextInt();

                        String update =
                            "UPDATE tasks SET status = 'Completed' WHERE id = ?";

                        try (PreparedStatement ps =
                                con.prepareStatement(update)) {
                            ps.setInt(1, updateId);
                            int rows = ps.executeUpdate();

                            System.out.println(rows > 0
                                ? "Task marked completed!"
                                : "Task ID not found.");
                        }
                        break;

                    case 4:
                        System.out.print("Enter task ID to delete: ");
                        int deleteId = sc.nextInt();

                        String delete = "DELETE FROM tasks WHERE id = ?";

                        try (PreparedStatement ps =
                                con.prepareStatement(delete)) {
                            ps.setInt(1, deleteId);
                            int rows = ps.executeUpdate();

                            System.out.println(rows > 0
                                ? "Task deleted successfully!"
                                : "Task ID not found.");
                        }
                        break;

                    case 5:
                        System.out.println("Thank you!");
                        sc.close();
                        return;

                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            }

        } catch (SQLException e) {
            System.out.println("Database error: " + e.getMessage());
        }
    }
}